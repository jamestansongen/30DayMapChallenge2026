using UnityEngine;

// A pedestrian waiting area on one corner of the crossing.
// People spawn and wait inside it, and finish their crossing inside another one.
public class CornerZone : MonoBehaviour
{
    [Tooltip("Radius of the waiting area in metres")]
    public float radius = 6f;

    [Tooltip("Relative share of people who start or end here (e.g. station corner = 3)")]
    public float weight = 1f;

    public Vector2 Pos2 => new Vector2(transform.position.x, transform.position.z);

    public Vector2 RandomPoint()
    {
        return Pos2 + Random.insideUnitCircle * radius;
    }

    void OnDrawGizmos()
    {
        Gizmos.color = new Color(0.2f, 1f, 0.4f, 0.8f);
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
