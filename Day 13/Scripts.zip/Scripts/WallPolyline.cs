using UnityEngine;

// A kerb, building front or barrier that pedestrians are pushed away from.
// Each child transform is one vertex, in order. Leave gaps where people may walk.
public class WallPolyline : MonoBehaviour
{
    public bool closed = false;

    public Vector2[] GetPoints()
    {
        int n = transform.childCount;
        var pts = new Vector2[n];
        for (int i = 0; i < n; i++)
        {
            Vector3 p = transform.GetChild(i).position;
            pts[i] = new Vector2(p.x, p.z);
        }
        return pts;
    }

    void OnDrawGizmos()
    {
        int n = transform.childCount;
        if (n < 2) return;
        Gizmos.color = new Color(1f, 0.5f, 0.1f, 1f);
        for (int i = 0; i < n - 1; i++)
            Gizmos.DrawLine(transform.GetChild(i).position, transform.GetChild(i + 1).position);
        if (closed)
            Gizmos.DrawLine(transform.GetChild(n - 1).position, transform.GetChild(0).position);
    }
}
