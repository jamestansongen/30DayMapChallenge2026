using System.Collections.Generic;
using System.IO;
using UnityEngine;

// One-shot social-force crowd simulation for a scramble crossing.
//
// Reset  -> a crowd spawns at the markers (CornerZones, e.g. next to traffic lights)
// Go     -> after a short pause everyone crosses to a different marker
// Finish -> when the last person has arrived the run stops and its results stay on screen
//
// World layout: X = east (m), Y = up, Z = north (m). Ground is at Y = groundY.
public class CrowdSim : MonoBehaviour
{
    public enum SimState { Idle, Waiting, Crossing, Finished }
    public enum HeatmapMode { Footfall, Conflicts }

    [Header("Scene references")]
    [Tooltip("Waiting areas next to each traffic light. People start in one and cross to another.")]
    public CornerZone[] markers;
    [Tooltip("Optional kerbs / building fronts people are pushed away from")]
    public WallPolyline[] walls;
    [Tooltip("Area the simulation covers, in world X/Z metres (x, z, width, depth)")]
    public Rect worldBounds = new Rect(-100f, -100f, 200f, 200f);
    [Tooltip("Height of the road surface in world Y")]
    public float groundY = 0f;

    [Header("Experiment (bind these to UI sliders; applied on Reset)")]
    [Range(10, 3000)] public int crowdSize = 800;
    [Range(0f, 1f)] public float aggressiveShare = 0.2f;
    [Range(0.25f, 8f)] public float simSpeed = 1f;

    [Header("Run control")]
    [Tooltip("Spawn a crowd and run automatically when Play starts")]
    public bool runOnStart = true;
    [Tooltip("Seconds people stand and settle before everyone starts crossing")]
    public float startDelay = 2f;
    [Tooltip("Give up after this many simulated seconds (gridlock safety)")]
    public float maxDuration = 300f;

    [Header("Polite (x)  ->  aggressive (y)")]
    [Tooltip("Preferred walking speed, m/s")]
    public Vector2 desiredSpeed = new Vector2(1.3f, 1.7f);
    [Tooltip("Extra personal space beyond the body, m")]
    public Vector2 personalSpace = new Vector2(0.2f, 0.0f);
    [Tooltip("How hard others push you away, m/s^2")]
    public Vector2 repulsionStrength = new Vector2(2.0f, 1.0f);
    [Tooltip("How far that push reaches, m")]
    public Vector2 repulsionRange = new Vector2(0.3f, 0.2f);
    [Tooltip("0 = ignore the flow, 1 = strongly join same-direction lanes")]
    public Vector2 laneFollowing = new Vector2(0.6f, 0f);
    [Tooltip("Attention to people beside/behind you (1 = all directions, 0 = only straight ahead)")]
    public Vector2 rearAwareness = new Vector2(0.5f, 0.15f);
    [Tooltip("Sidestep to the left when someone comes head-on (people in Tokyo tend to keep left)")]
    public Vector2 keepLeft = new Vector2(0.5f, 0.1f);
    [Tooltip("Max random delay before stepping off once the crossing starts, s")]
    public Vector2 reactionTime = new Vector2(1.2f, 0.3f);

    [Header("Shared physics")]
    public float bodyRadius = 0.25f;
    public float relaxationTime = 0.5f;
    public float bodyStiffness = 60f;
    public float wallStrength = 6f;
    public float wallRange = 0.25f;
    public float maxAccel = 30f;
    public float maxSpeedFactor = 1.35f;
    public float neighbourRadius = 2f;
    [Tooltip("Small random jostle that stops perfectly balanced stand-offs, m/s^2")]
    public float noise = 0.3f;
    [Tooltip("Crossers count as arrived this far outside their destination marker's radius, m")]
    public float arrivalMargin = 1f;
    [Tooltip("Floor space per person standing at a corner, m^2. The arrival zone grows as people pile up there.")]
    public float areaPerPerson = 0.5f;
    [Tooltip("Someone pinned behind a crowd near their corner for this long counts as arrived, s")]
    public float stuckArrivalTime = 6f;
    [Tooltip("How much people already standing at a corner resist someone still crossing (0 = not at all, 1 = fully)")]
    [Range(0f, 1f)] public float standingCrowdSoftness = 0.2f;
    const float Dt = 0.04f;           // fixed simulation step (25 Hz)
    const int MaxStepsPerFrame = 40;

    [Header("Rendering (enable GPU Instancing on both materials)")]
    [Tooltip("Simple shape for people without a character model (e.g. Capsule)")]
    public Mesh agentMesh;
    public Material politeMaterial;
    public Material aggressiveMaterial;
    public float agentDiameter = 0.5f;
    public float agentHeight = 1.7f;
    public bool castShadows = true;

    [Header("Character models (optional)")]
    [Tooltip("People prefabs; each person gets a random one. Leave empty to use the simple shape.")]
    public GameObject[] characterPrefabs;
    [Tooltip("Above this many people, the rest are drawn with the simple shape (performance)")]
    public int maxCharacters = 800;
    [Tooltip("How quickly characters turn to face their walking direction")]
    public float turnSpeed = 8f;
    [Tooltip("Flat disc drawn under each character in the polite/aggressive colour (e.g. Cylinder). Leave empty for none.")]
    public Mesh markerMesh;
    public float markerDiameter = 0.7f;

    [Header("Heatmap (optional)")]
    [Tooltip("A flat quad covering worldBounds, with an unlit transparent material")]
    public Renderer heatmapRenderer;
    public HeatmapMode heatmapMode = HeatmapMode.Conflicts;
    public int heatmapResolution = 256;

    [Header("Logging")]
    [Tooltip("Append one CSV row per finished run to Application.persistentDataPath/crossing_log.csv")]
    public bool logRuns = true;

    // ---------- live stats (read by CrowdUI) ----------
    public SimState State { get; private set; } = SimState.Idle;
    public float Elapsed { get; private set; }          // seconds since the crossing started
    public int TotalCount => count;
    public int WaitingCount { get; private set; }
    public int CrossingCount { get; private set; }
    public int ArrivedCount { get; private set; }
    public int Bumps { get; private set; }
    public float AvgCrossPolite => nCrossP > 0 ? sumCrossP / nCrossP : -1f;
    public float AvgCrossAggressive => nCrossA > 0 ? sumCrossA / nCrossA : -1f;
    public bool TimedOut { get; private set; }
    public int RunsCompleted { get; private set; }
    public string LogPath { get; private set; }
    // settings the current run was spawned with (sliders may have moved since)
    public int RunCrowdSize { get; private set; }
    public float RunAggressiveShare { get; private set; }

    struct Agent
    {
        public Vector2 pos, vel, goal;
        public float aggression, v0, startDelay, bumpCooldown, crossTime, stallTime;
        public int state;   // 0 = waiting, 1 = crossing, 2 = arrived
        public int dest;    // index into markers
    }

    Agent[] agents;
    Vector2[] accel;
    int count, capacity;
    float accumulator, waitTimer;
    float sumCrossP, sumCrossA;
    int nCrossP, nCrossA;
    int[] standingAt;   // people currently standing at each marker (waiting or arrived)
    readonly List<Vector4> wallSegs = new List<Vector4>();

    // spatial hash grid
    float cellSize;
    int gridW, gridH;
    int[] cellStart, cellCount, cellFill, sorted, agentCell;

    // rendering
    Transform[] characters;     // per agent index; null = drawn as simple shape
    GameObject crowdRoot;

    // heatmap
    float[] heat;
    Texture2D heatTex;
    Color32[] heatPixels;
    float heatTimer;

    // ======================================================================

    void Awake()
    {
        capacity = 3000;
        Allocate(capacity);
        BuildWalls();
        SetupHeatmap();

        if (logRuns)
        {
            LogPath = Path.Combine(Application.persistentDataPath, "crossing_log.csv");
            if (!File.Exists(LogPath))
                File.WriteAllText(LogPath, "run,crowd_size,aggressive_share,clear_time_s,timed_out,bumps,avg_cross_polite_s,avg_cross_aggressive_s\n");
            Debug.Log("Crossing log: " + LogPath);
        }
    }

    void Start()
    {
        if (runOnStart) ResetSim();
    }

    void Allocate(int n)
    {
        agents = new Agent[n];
        accel = new Vector2[n];
        characters = new Transform[n];
        SetupGrid(n);
    }

    void Update()
    {
        if (State == SimState.Waiting || State == SimState.Crossing)
        {
            accumulator += Time.deltaTime * simSpeed;
            int steps = 0;
            while (accumulator >= Dt && steps < MaxStepsPerFrame &&
                   (State == SimState.Waiting || State == SimState.Crossing))
            {
                Step();
                accumulator -= Dt;
                steps++;
            }
            if (steps == MaxStepsPerFrame) accumulator = 0f;
        }

        heatTimer += Time.deltaTime;
        if (heatTimer > 0.25f) { heatTimer = 0f; UpdateHeatTexture(); }

        Render();
    }

    // ------------------------------------------------------------ run control

    // Clear everything, spawn a new crowd with the current slider values, and start the countdown.
    public void ResetSim()
    {
        if (markers == null || markers.Length < 2)
        {
            Debug.LogWarning("CrowdSim needs at least 2 markers.");
            return;
        }

        DestroyCharacters();
        if (crowdSize > capacity)
        {
            capacity = crowdSize;
            Allocate(capacity);
        }

        count = 0;
        accumulator = 0f;
        Elapsed = 0f;
        Bumps = 0;
        TimedOut = false;
        sumCrossP = sumCrossA = 0f;
        nCrossP = nCrossA = 0;
        RunCrowdSize = crowdSize;
        RunAggressiveShare = aggressiveShare;
        if (heat != null) System.Array.Clear(heat, 0, heat.Length);

        SpawnCrowd(crowdSize);
        CreateCharacters();
        CountStates();

        waitTimer = startDelay;
        State = SimState.Waiting;
        UpdateHeatTexture();
    }

    // Start crossing now (skips the remaining countdown).
    public void Go()
    {
        if (State != SimState.Waiting) return;
        for (int i = 0; i < count; i++)
            agents[i].startDelay = Random.Range(0f, Lerp(reactionTime, agents[i].aggression));
        Elapsed = 0f;
        State = SimState.Crossing;
    }

    void Finish(bool timedOut)
    {
        TimedOut = timedOut;
        State = SimState.Finished;
        RunsCompleted++;
        WriteLogRow();
    }

    // ---------------------------------------------------------------- step

    void Step()
    {
        if (State == SimState.Waiting)
        {
            waitTimer -= Dt;
            if (waitTimer <= 0f) Go();
        }
        else
        {
            Elapsed += Dt;
            for (int i = 0; i < count; i++)
            {
                if (agents[i].state != 0) continue;
                agents[i].startDelay -= Dt;
                if (agents[i].startDelay <= 0f)
                {
                    agents[i].state = 1;
                    agents[i].crossTime = 0f;
                    agents[i].stallTime = 0f;
                    agents[i].goal = markers[agents[i].dest].RandomPoint();
                }
            }
        }

        ComputeAccelerations();
        Integrate();
        CheckArrivals();
        CountStates();

        if (State == SimState.Crossing)
        {
            if (WaitingCount == 0 && CrossingCount == 0) Finish(false);
            else if (Elapsed >= maxDuration) Finish(true);
        }
    }

    // ------------------------------------------------------------- spawning

    void SpawnCrowd(int n)
    {
        float minGap2 = (2f * bodyRadius) * (2f * bodyRadius);
        for (int k = 0; k < n; k++)
        {
            int o = PickMarker(-1);
            int d = PickMarker(o);
            float ag = Random.value < aggressiveShare ? 1f : 0f;

            // Try a few spots so people don't start on top of each other.
            Vector2 p = markers[o].RandomPoint();
            for (int attempt = 0; attempt < 8; attempt++)
            {
                bool clear = true;
                for (int j = 0; j < count; j++)
                {
                    if ((agents[j].pos - p).sqrMagnitude < minGap2) { clear = false; break; }
                }
                if (clear) break;
                p = markers[o].RandomPoint();
            }

            agents[count++] = new Agent
            {
                pos = p,
                vel = Vector2.zero,
                goal = p,
                aggression = ag,
                v0 = Lerp(desiredSpeed, ag) * Random.Range(0.85f, 1.15f),
                startDelay = 0f,
                bumpCooldown = 0f,
                crossTime = 0f,
                state = 0,
                dest = d
            };
        }
    }

    int PickMarker(int exclude)
    {
        float total = 0f;
        for (int i = 0; i < markers.Length; i++)
            if (i != exclude) total += Mathf.Max(0f, markers[i].weight);

        float r = Random.value * total;
        int last = -1;
        for (int i = 0; i < markers.Length; i++)
        {
            if (i == exclude) continue;
            last = i;
            r -= Mathf.Max(0f, markers[i].weight);
            if (r <= 0f) return i;
        }
        return last;
    }

    // A crosser has arrived once they reach the crowd standing at their destination corner.
    // The zone grows with that crowd, so latecomers don't get stuck behind it.
    // They stay visible there (state 2) and shuffle to a free spot.
    void CheckArrivals()
    {
        if (standingAt == null || standingAt.Length != markers.Length) standingAt = new int[markers.Length];
        System.Array.Clear(standingAt, 0, standingAt.Length);
        for (int i = 0; i < count; i++)
        {
            if (agents[i].state == 2) standingAt[agents[i].dest]++;
        }

        for (int i = 0; i < count; i++)
        {
            if (agents[i].state != 1) continue;
            int m = agents[i].dest;
            CornerZone c = markers[m];
            float crowdR = Mathf.Sqrt(c.radius * c.radius + standingAt[m] * areaPerPerson / Mathf.PI);
            float r = crowdR + arrivalMargin;
            float d2 = (c.Pos2 - agents[i].pos).sqrMagnitude;

            // Pinned against the crowd near the corner? Track how long they've been barely moving.
            if (agents[i].vel.sqrMagnitude < 0.3f * 0.3f) agents[i].stallTime += Dt;
            else agents[i].stallTime = 0f;
            bool pinned = agents[i].stallTime > stuckArrivalTime && d2 < (r + 5f) * (r + 5f);

            if (d2 < r * r || pinned)
            {
                agents[i].state = 2;
                standingAt[m]++;
                if (agents[i].aggression > 0.5f) { sumCrossA += agents[i].crossTime; nCrossA++; }
                else { sumCrossP += agents[i].crossTime; nCrossP++; }
            }
        }
    }

    void CountStates()
    {
        int w = 0, c = 0, a = 0;
        for (int i = 0; i < count; i++)
        {
            switch (agents[i].state)
            {
                case 0: w++; break;
                case 1: c++; break;
                default: a++; break;
            }
        }
        WaitingCount = w;
        CrossingCount = c;
        ArrivedCount = a;
    }

    // ---------------------------------------------------------- social force

    void ComputeAccelerations()
    {
        BuildGrid();

        for (int i = 0; i < count; i++)
        {
            ref Agent a = ref agents[i];
            float ag = a.aggression;
            bool crossing = a.state == 1;

            Vector2 toGoal = a.goal - a.pos;
            float dist = toGoal.magnitude;
            Vector2 dir = dist > 1e-4f ? toGoal / dist : Vector2.zero;

            // Waiting and arrived people shuffle gently; crossing people walk at their own pace.
            float v0 = crossing ? a.v0 : 0.5f;
            float speedTarget = v0 * Mathf.Clamp01(dist / (crossing ? 1f : 0.5f));
            Vector2 heading = a.vel.sqrMagnitude > 0.01f ? a.vel.normalized : dir;

            float A = Lerp(repulsionStrength, ag);
            float B = Lerp(repulsionRange, ag);
            float space = Lerp(personalSpace, ag);
            float lambda = Lerp(rearAwareness, ag);
            float laneW = (crossing && dist > 3f) ? Lerp(laneFollowing, ag) : 0f;

            Vector2 f = Vector2.zero;
            Vector2 align = Vector2.zero;
            int alignN = 0;
            int headOn = 0;

            CellOf(a.pos, out int cx, out int cy);
            for (int gy = cy - 1; gy <= cy + 1; gy++)
            {
                if (gy < 0 || gy >= gridH) continue;
                for (int gx = cx - 1; gx <= cx + 1; gx++)
                {
                    if (gx < 0 || gx >= gridW) continue;
                    int cell = gy * gridW + gx;
                    int s = cellStart[cell], e = s + cellCount[cell];
                    for (int k = s; k < e; k++)
                    {
                        int j = sorted[k];
                        if (j == i) continue;

                        Vector2 d = a.pos - agents[j].pos;
                        float dij = d.magnitude;
                        if (dij > neighbourRadius || dij < 1e-5f) continue;
                        Vector2 n = d / dij;

                        // People standing at a corner (arrived) step aside for someone still crossing,
                        // so a crosser is never trapped inside a crowd that has already arrived.
                        float soft = (crossing && agents[j].state == 2) ? standingCrowdSoftness : 1f;

                        // Social repulsion, stronger for people in front of you.
                        float rij = 2f * bodyRadius + space;
                        float cosPhi = -Vector2.Dot(n, heading);
                        float w = lambda + (1f - lambda) * 0.5f * (1f + cosPhi);
                        f += soft * A * Mathf.Exp((rij - dij) / B) * w * n;

                        // Physical contact.
                        float overlap = 2f * bodyRadius - dij;
                        if (overlap > 0f)
                        {
                            f += soft * bodyStiffness * overlap * n;
                            if (crossing && a.bumpCooldown <= 0f)
                            {
                                a.bumpCooldown = 1.5f;
                                Bumps++;
                                AddHeat(a.pos, 1f, HeatmapMode.Conflicts);
                            }
                        }

                        // Someone ahead walking towards you?
                        if (crossing && cosPhi > 0.7f && Vector2.Dot(agents[j].vel, heading) < -0.3f)
                            headOn++;

                        // Lane following: notice nearby people heading the same way.
                        if (laneW > 0f && dij < 1.5f)
                        {
                            Vector2 vj = agents[j].vel;
                            float sj = vj.magnitude;
                            if (sj > 0.3f && Vector2.Dot(vj / sj, dir) > 0.7f)
                            {
                                align += vj / sj;
                                alignN++;
                            }
                        }
                    }
                }
            }

            if (alignN > 0)
            {
                Vector2 avg = (align / alignN).normalized;
                dir = Vector2.Lerp(dir, avg, laneW * 0.5f).normalized;
            }

            if (headOn > 0)
            {
                Vector2 left = new Vector2(-dir.y, dir.x);
                dir = (dir + left * Lerp(keepLeft, ag) * Mathf.Min(1f, headOn * 0.35f)).normalized;
            }

            // Driving force towards the goal.
            f += (dir * speedTarget - a.vel) / relaxationTime;

            // Walls and kerbs.
            for (int wi = 0; wi < wallSegs.Count; wi++)
            {
                Vector4 seg = wallSegs[wi];
                Vector2 cp = ClosestPoint(new Vector2(seg.x, seg.y), new Vector2(seg.z, seg.w), a.pos);
                Vector2 dw = a.pos - cp;
                float dd = dw.magnitude;
                if (dd > 1.5f || dd < 1e-5f) continue;
                Vector2 nw = dw / dd;
                f += wallStrength * Mathf.Exp((bodyRadius - dd) / wallRange) * nw;
                if (dd < bodyRadius) f += bodyStiffness * (bodyRadius - dd) * nw;
            }

            if (noise > 0f) f += Random.insideUnitCircle * noise;

            if (f.sqrMagnitude > maxAccel * maxAccel) f = f.normalized * maxAccel;
            accel[i] = f;
        }
    }

    void Integrate()
    {
        for (int i = 0; i < count; i++)
        {
            ref Agent a = ref agents[i];
            a.vel += accel[i] * Dt;
            float vmax = a.state == 1 ? a.v0 * maxSpeedFactor : 0.8f;
            if (a.vel.sqrMagnitude > vmax * vmax) a.vel = a.vel.normalized * vmax;
            a.pos += a.vel * Dt;
            a.pos.x = Mathf.Clamp(a.pos.x, worldBounds.xMin, worldBounds.xMax);
            a.pos.y = Mathf.Clamp(a.pos.y, worldBounds.yMin, worldBounds.yMax);
            a.bumpCooldown -= Dt;
            if (a.state == 1)
            {
                a.crossTime += Dt;
                AddHeat(a.pos, Dt, HeatmapMode.Footfall);
            }
        }
    }

    // ---------------------------------------------------------------- walls

    void BuildWalls()
    {
        wallSegs.Clear();
        if (walls == null) return;
        foreach (var wall in walls)
        {
            if (!wall) continue;
            Vector2[] p = wall.GetPoints();
            for (int i = 0; i < p.Length - 1; i++)
                wallSegs.Add(new Vector4(p[i].x, p[i].y, p[i + 1].x, p[i + 1].y));
            if (wall.closed && p.Length > 2)
                wallSegs.Add(new Vector4(p[p.Length - 1].x, p[p.Length - 1].y, p[0].x, p[0].y));
        }
    }

    static Vector2 ClosestPoint(Vector2 a, Vector2 b, Vector2 p)
    {
        Vector2 ab = b - a;
        float t = Vector2.Dot(p - a, ab) / Mathf.Max(ab.sqrMagnitude, 1e-6f);
        return a + ab * Mathf.Clamp01(t);
    }

    // ------------------------------------------------------------ spatial grid

    void SetupGrid(int n)
    {
        cellSize = neighbourRadius;
        gridW = Mathf.Max(1, Mathf.CeilToInt(worldBounds.width / cellSize));
        gridH = Mathf.Max(1, Mathf.CeilToInt(worldBounds.height / cellSize));
        int cells = gridW * gridH;
        cellStart = new int[cells];
        cellCount = new int[cells];
        cellFill = new int[cells];
        sorted = new int[n];
        agentCell = new int[n];
    }

    void CellOf(Vector2 p, out int cx, out int cy)
    {
        cx = Mathf.Clamp((int)((p.x - worldBounds.x) / cellSize), 0, gridW - 1);
        cy = Mathf.Clamp((int)((p.y - worldBounds.y) / cellSize), 0, gridH - 1);
    }

    void BuildGrid()
    {
        System.Array.Clear(cellCount, 0, cellCount.Length);
        for (int i = 0; i < count; i++)
        {
            CellOf(agents[i].pos, out int cx, out int cy);
            int c = cy * gridW + cx;
            agentCell[i] = c;
            cellCount[c]++;
        }
        int run = 0;
        for (int c = 0; c < cellCount.Length; c++)
        {
            cellStart[c] = run;
            cellFill[c] = run;
            run += cellCount[c];
        }
        for (int i = 0; i < count; i++)
            sorted[cellFill[agentCell[i]]++] = i;
    }

    // ------------------------------------------------------------- rendering

    void CreateCharacters()
    {
        if (characterPrefabs == null || characterPrefabs.Length == 0) return;
        crowdRoot = new GameObject("Crowd (generated)");
        int n = Mathf.Min(count, maxCharacters);
        for (int i = 0; i < n; i++)
        {
            GameObject prefab = characterPrefabs[Random.Range(0, characterPrefabs.Length)];
            if (prefab == null) continue;
            Vector3 pos = new Vector3(agents[i].pos.x, groundY, agents[i].pos.y);
            // Start facing roughly towards the crossing centre.
            Vector3 look = new Vector3(-agents[i].pos.x, 0f, -agents[i].pos.y);
            Quaternion rot = look.sqrMagnitude > 0.01f ? Quaternion.LookRotation(look) : Quaternion.identity;
            characters[i] = Instantiate(prefab, pos, rot, crowdRoot.transform).transform;
        }
    }

    void DestroyCharacters()
    {
        if (crowdRoot != null) Destroy(crowdRoot);
        crowdRoot = null;
        if (characters != null) System.Array.Clear(characters, 0, characters.Length);
    }

    readonly List<Matrix4x4> politeShapes = new List<Matrix4x4>();
    readonly List<Matrix4x4> aggressiveShapes = new List<Matrix4x4>();
    readonly List<Matrix4x4> politeDiscs = new List<Matrix4x4>();
    readonly List<Matrix4x4> aggressiveDiscs = new List<Matrix4x4>();

    void Render()
    {
        if (count == 0) return;
        politeShapes.Clear(); aggressiveShapes.Clear();
        politeDiscs.Clear(); aggressiveDiscs.Clear();

        Vector3 shapeScale = new Vector3(agentDiameter, agentHeight * 0.5f, agentDiameter); // capsule/cylinder are 2 units tall
        Vector3 discScale = new Vector3(markerDiameter, 0.01f, markerDiameter);
        float turn = 1f - Mathf.Exp(-turnSpeed * Time.deltaTime);

        for (int i = 0; i < count; i++)
        {
            Vector2 p = agents[i].pos;
            Vector2 v = agents[i].vel;
            bool aggressive = agents[i].aggression > 0.5f;
            Transform ch = characters[i];

            if (ch != null)
            {
                ch.position = new Vector3(p.x, groundY, p.y);
                if (v.sqrMagnitude > 0.04f)
                    ch.rotation = Quaternion.Slerp(ch.rotation, Quaternion.LookRotation(new Vector3(v.x, 0f, v.y)), turn);
                if (markerMesh != null)
                {
                    Matrix4x4 d = Matrix4x4.TRS(new Vector3(p.x, groundY + 0.02f, p.y), Quaternion.identity, discScale);
                    (aggressive ? aggressiveDiscs : politeDiscs).Add(d);
                }
            }
            else
            {
                Quaternion rot = v.sqrMagnitude > 0.01f
                    ? Quaternion.LookRotation(new Vector3(v.x, 0f, v.y))
                    : Quaternion.identity;
                Matrix4x4 m = Matrix4x4.TRS(new Vector3(p.x, groundY + agentHeight * 0.5f, p.y), rot, shapeScale);
                (aggressive ? aggressiveShapes : politeShapes).Add(m);
            }
        }

        Draw(politeMaterial, agentMesh, politeShapes);
        Draw(aggressiveMaterial, agentMesh, aggressiveShapes);
        Draw(politeMaterial, markerMesh, politeDiscs);
        Draw(aggressiveMaterial, markerMesh, aggressiveDiscs);
    }

    void Draw(Material mat, Mesh mesh, List<Matrix4x4> mats)
    {
        int n = mats.Count;
        if (mat == null || mesh == null || n == 0) return;
        var rp = new RenderParams(mat)
        {
            shadowCastingMode = castShadows ? UnityEngine.Rendering.ShadowCastingMode.On : UnityEngine.Rendering.ShadowCastingMode.Off,
            receiveShadows = true
        };
        for (int s = 0; s < n; s += 1023)
            Graphics.RenderMeshInstanced(rp, mesh, 0, mats, Mathf.Min(1023, n - s), s);
    }

    // --------------------------------------------------------------- heatmap

    void SetupHeatmap()
    {
        if (heatmapRenderer == null) return;
        int r = heatmapResolution;
        heat = new float[r * r];
        heatPixels = new Color32[r * r];
        heatTex = new Texture2D(r, r, TextureFormat.RGBA32, false)
        {
            wrapMode = TextureWrapMode.Clamp,
            filterMode = FilterMode.Bilinear
        };
        heatmapRenderer.material.mainTexture = heatTex;
        UpdateHeatTexture();
    }

    void AddHeat(Vector2 p, float amount, HeatmapMode mode)
    {
        if (heat == null || mode != heatmapMode) return;
        int r = heatmapResolution;
        int x = (int)((p.x - worldBounds.x) / worldBounds.width * r);
        int y = (int)((p.y - worldBounds.y) / worldBounds.height * r);
        if (x < 0 || y < 0 || x >= r || y >= r) return;
        heat[y * r + x] += amount;
    }

    void UpdateHeatTexture()
    {
        if (heat == null || heatTex == null) return;
        float max = 0f;
        for (int i = 0; i < heat.Length; i++) if (heat[i] > max) max = heat[i];
        for (int i = 0; i < heat.Length; i++)
        {
            float t = max > 0f ? Mathf.Sqrt(heat[i] / max) : 0f;
            heatPixels[i] = Ramp(t);
        }
        heatTex.SetPixels32(heatPixels);
        heatTex.Apply(false);
    }

    static Color32 Ramp(float t)
    {
        if (t <= 0.001f) return new Color32(0, 0, 0, 0);
        Color c;
        if (t < 0.5f) c = Color.Lerp(new Color(1f, 0.95f, 0.3f, 0.15f), new Color(1f, 0.55f, 0.1f, 0.6f), t / 0.5f);
        else c = Color.Lerp(new Color(1f, 0.55f, 0.1f, 0.6f), new Color(0.75f, 0.05f, 0.1f, 0.9f), (t - 0.5f) / 0.5f);
        return c;
    }

    // --------------------------------------------------------------- logging

    void WriteLogRow()
    {
        if (!logRuns || string.IsNullOrEmpty(LogPath)) return;
        var inv = System.Globalization.CultureInfo.InvariantCulture;
        string ap = AvgCrossPolite < 0f ? "" : AvgCrossPolite.ToString("0.00", inv);
        string aa = AvgCrossAggressive < 0f ? "" : AvgCrossAggressive.ToString("0.00", inv);
        File.AppendAllText(LogPath,
            $"{RunsCompleted},{RunCrowdSize},{RunAggressiveShare.ToString("0.00", inv)},{Elapsed.ToString("0.00", inv)},{(TimedOut ? 1 : 0)},{Bumps},{ap},{aa}\n");
    }

    static float Lerp(Vector2 range, float t) => Mathf.Lerp(range.x, range.y, t);

#if UNITY_EDITOR
    void OnDrawGizmos()
    {
        Gizmos.color = new Color(0.3f, 0.6f, 1f, 0.6f);
        Vector3 c = new Vector3(worldBounds.center.x, groundY, worldBounds.center.y);
        Gizmos.DrawWireCube(c, new Vector3(worldBounds.width, 0f, worldBounds.height));
    }
#endif
}