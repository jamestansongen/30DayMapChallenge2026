using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using TMPro;

// Connects UI controls to CrowdSim and shows live stats.
// Crowd size and aggressive share apply when you press Reset; sim speed applies immediately.
public class CrowdUI : MonoBehaviour
{
    public CrowdSim sim;

    [Header("Controls")]
    public Slider crowdSlider;
    public Slider aggressionSlider;
    public Slider speedSlider;
    public Button resetButton;
    [Tooltip("Optional: start crossing immediately instead of waiting for the countdown")]
    public Button goButton;

    [Header("Labels")]
    public TMP_Text crowdLabel;
    public TMP_Text aggressionLabel;
    public TMP_Text speedLabel;
    public TMP_Text statsText;

    void Start()
    {
        Setup(crowdSlider, 50f, 3000f, sim.crowdSize, true, v => sim.crowdSize = Mathf.RoundToInt(v));
        Setup(aggressionSlider, 0f, 1f, sim.aggressiveShare, false, v => sim.aggressiveShare = v);
        Setup(speedSlider, 0.25f, 8f, sim.simSpeed, false, v => sim.simSpeed = v);
        if (resetButton) resetButton.onClick.AddListener(sim.ResetSim);
        if (goButton) goButton.onClick.AddListener(sim.Go);
    }

    static void Setup(Slider s, float min, float max, float value, bool whole, UnityAction<float> onChange)
    {
        if (!s) return;
        s.minValue = min;
        s.maxValue = max;
        s.wholeNumbers = whole;
        s.value = value;
        s.onValueChanged.AddListener(onChange);
    }

    static string Secs(float s) => s < 0f ? "-" : $"{s:0.0} s";

    void Update()
    {
        if (crowdLabel) crowdLabel.text = $"Crowd size: {sim.crowdSize}";
        if (aggressionLabel) aggressionLabel.text = $"Aggressive: {sim.aggressiveShare * 100f:0}%";
        if (speedLabel) speedLabel.text = $"Sim speed: {sim.simSpeed:0.0}x";

        if (!statsText) return;

        string status;
        switch (sim.State)
        {
            case CrowdSim.SimState.Idle: status = "Press Reset to spawn a crowd"; break;
            case CrowdSim.SimState.Waiting: status = "Waiting for the green light..."; break;
            case CrowdSim.SimState.Crossing: status = $"Crossing  {sim.Elapsed:0.0} s"; break;
            default:
                status = sim.TimedOut
                    ? $"Stopped at {sim.Elapsed:0} s - {sim.WaitingCount + sim.CrossingCount} people stuck"
                    : $"Everyone across in {sim.Elapsed:0.0} s";
                break;
        }

        statsText.text =
            $"{status}\n" +
            $"Run: {sim.RunCrowdSize} people, {sim.RunAggressiveShare * 100f:0}% aggressive\n" +
            $"Waiting {sim.WaitingCount}   Crossing {sim.CrossingCount}   Arrived {sim.ArrivedCount}\n" +
            $"Bumps: {sim.Bumps}\n" +
            $"Avg crossing time: polite {Secs(sim.AvgCrossPolite)}, aggressive {Secs(sim.AvgCrossAggressive)}";
    }
}
